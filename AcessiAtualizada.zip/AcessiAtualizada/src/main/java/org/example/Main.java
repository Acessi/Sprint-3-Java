package org.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.entities.Pessoa.Funcionario;
import org.example.entities.Pessoa.Usuario;
import org.example.entities.Problema.Notificacao;
import org.example.infrastructure.AppTestConfig;
import org.example.infrastructure.DatabaseConfig;
import org.example.repositories.PessoaRepository.FuncionarioRepository;
import org.example.repositories.PessoaRepository.UsuarioRepository;
import org.example.repositories.ProblemaRepository.NotificacaoRepository;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final String SENHA_MESTRE = "ACESSI_123";
    public static Logger logger = LogManager.getLogger(Main.class);

    public static void main(String[] args) {
        logger.info("Sistema Iniciando...");
            AppTestConfig.testApp();

            var usuarioRepository = new UsuarioRepository();
            var funcionarioRepository = new FuncionarioRepository();

            System.out.println("Bem vindo ao sistema Acessi");

            label:
            while (true) {
                System.out.println("Digite a opção desejada:");
                System.out.println("1 - Cadastrar Usuário");
                System.out.println("2 - Listar usuários");
                System.out.println("3 - Remover usuário");
                System.out.println("4 - Listar todos us usuários (ADMIN APENAS)");
                System.out.println("5 - Exportar arquivo de usuários");
                System.out.println("6 - Importar arquivo de usuários");
                System.out.println("7 - Buscar usuário por ID");
                System.out.println("8 - Listar passageiros");
                System.out.println("9 - Listar colaboradores");
                System.out.println("10 - Sair");
                var scan = new Scanner(System.in);
                var opcao = scan.nextInt();
                scan.nextLine();
                switch (opcao) {
                    case 1:
                        CadastrarUsuario(usuarioRepository);
                        System.out.println("Usuário cadastrado com sucesso!");
                        break;
                    case 2:
                        System.out.println(usuarioRepository.listar());
                        break;
                    case 3:
                        RemoverUsuario(usuarioRepository);
                        System.out.println("Usuário removido com sucesso!");
                        break;
                    case 4:
                        ListarTodosUsuarios(usuarioRepository);
                        break;
                    case 5:
                        usuarioRepository.exportarParaJson();
                        break;
                    case 6:
                        System.out.println("Digite o nome do arquivo:");
                        var nomeArquivo = scan.nextLine();
                        usuarioRepository.importar(nomeArquivo);
                        break;
                    case 7:
                        System.out.println("Digite o Id do Usuário:");
                        var id = scan.nextInt();
                        System.out.println(usuarioRepository.buscarPorId(id));
                        break;
                    case 8:
                        System.out.println("Lista de Passageiros:");
                        List<Usuario> passageiros = usuarioRepository.listarUsuariosPorTipo("Passageiro");
                        passageiros.forEach(System.out::println);
                        break;
                    case 9:
                        System.out.println("Lista de Colaboradores:");
                        List<Usuario> colaboradores = usuarioRepository.listarUsuariosPorTipo("Colaborador");
                        colaboradores.forEach(System.out::println);
                        break;
                    case 10:
                        break label;
                    default:
                        System.out.println("Opção inválida");
                        break;
                }
            }
        logger.info("Sistema finalizando...");
    }

        private static void CadastrarUsuario(UsuarioRepository repository) {
            try {
                var scan = new Scanner(System.in);
                System.out.println("Digite o nome de usuário");
                var nome = scan.nextLine();
                System.out.println("Digite seu e-mail");
                var email = scan.nextLine();
                System.out.println("Digite sua senha: ");
                var senha = scan.nextLine();
                System.out.println("Digite o tipo de usuário (Passageiro/Colaborador):");
                var tipo = scan.nextLine();
                var usuario = new Usuario(nome, email, senha, tipo);
                repository.adicionar(usuario);
                logger.info("Usuário cadastrado com sucesso {}", usuario);
            }
            catch(Exception e){
            System.out.println("Campo com valor incorreto");
            logger.error("Erro ao cadastrar usuário", e);
            }
        }

        public static void RemoverUsuario(UsuarioRepository repository) {
            System.out.println("Digite o id do usuário que deseja remover");
            var scan = new Scanner(System.in);
            var id = scan.nextInt();
            scan.nextLine();
            repository.deleteById(id);
        }

        public static void ListarTodosUsuarios(UsuarioRepository repository){
            var scan = new Scanner(System.in);
            System.out.println("Digite a senha de administrador");
            var senha = scan.nextLine();
            if (senha.equals(SENHA_MESTRE))
                System.out.println(repository.listarTodos());
            else
                System.out.println("Acesso não autorizado");
        }
}