package org.example.entities.Metro;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.entities.Pessoa._BaseEntity;

import java.time.LocalTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Estacao extends _BaseEntity {
    private String nome;
    private String horarioAbertura;
    private String horarioFechamento;
    private String localizacao;
}
