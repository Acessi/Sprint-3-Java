package org.example.entities.Metro;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.entities.Pessoa._BaseEntity;

import java.time.LocalTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Linha extends _BaseEntity {
    private String nome;
    private List<Estacao> estacoes;
}
