package org.example.entities.Metro;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.entities.Pessoa._BaseEntity;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Trem extends _BaseEntity {
    private String origem;
    private String destino;
    private Linha linha;
    private int capacidadeMaxima;
    private int capacidadeAtual;
    private boolean operando;
}
