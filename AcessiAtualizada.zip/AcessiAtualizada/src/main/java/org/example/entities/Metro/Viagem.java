package org.example.entities.Metro;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.entities.Pessoa.Passageiro;
import org.example.entities.Pessoa._BaseEntity;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Viagem extends _BaseEntity {
    private int duracao;
    private Passageiro passageiro;
    private Estacao estacaoOrigem;
    private Estacao estacaoDestino;
    private LocalDateTime dataHora;
}
