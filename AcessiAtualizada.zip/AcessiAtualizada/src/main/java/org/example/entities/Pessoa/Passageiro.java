package org.example.entities.Pessoa;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

// @AllArgsConstructor - entender pq está dando erro
@Data
@NoArgsConstructor
public class Passageiro extends Usuario{
}
