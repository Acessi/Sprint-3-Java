package org.example.entities.Pessoa;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Usuario extends _BaseEntity {
    private String nome;
    private String email;
    private String senha;
    private String tipo;
}
