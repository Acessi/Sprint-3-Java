package org.example.entities.Problema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.entities.Pessoa.Usuario;
import org.example.entities.Pessoa._BaseEntity;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Conversa extends _BaseEntity {
    private Usuario usuario;
    private String assunto;
    private String modeloLLM;
    private String mensagem;
    private boolean encerrada;
    private LocalDateTime dataHoraMensagem;
}
