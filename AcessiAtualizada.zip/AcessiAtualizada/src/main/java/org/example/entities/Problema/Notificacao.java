package org.example.entities.Problema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.entities.Pessoa.Usuario;
import org.example.entities.Pessoa._BaseEntity;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Notificacao extends _BaseEntity {
    private int id;
    private String mensagem;
    private String titulo;
    private LocalDateTime dataHora;
}
