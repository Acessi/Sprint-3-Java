package org.example.repositories.PessoaRepository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.entities.Pessoa.Funcionario;
import org.example.entities.Pessoa.Usuario;
import org.example.entities.Problema.Notificacao;
import org.example.infrastructure.DatabaseConfig;
import org.example.repositories.CrudRepository;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FuncionarioRepository implements CrudRepository<Funcionario> {
    public static Logger logger = LogManager.getLogger(FuncionarioRepository.class);
    private List<Funcionario> funcionarios = new ArrayList<>(List.of());

    @Override
    public void adicionar(Funcionario object) {
        var query = "INSERT INTO FUNCIONARIO (DELETED, NOME, EMAIL, SENHA, TIPO, CARGO) VALUES (?,?,?,?,?,?)";
        try(var conn = DatabaseConfig.getConnection())
        {
            var stmt = conn.prepareStatement(query);
            stmt.setBoolean(1, false);
            stmt.setString(2, object.getNome());
            stmt.setString(3, object.getEmail());
            stmt.setString(4, object.getSenha());
            stmt.setString(5, object.getTipo());
            stmt.setString(6, object.getCargo());
            var result = stmt.executeUpdate();
            if(result > 0)
                logger.info("Funcionario adicionado com sucesso!");
        }
        catch(SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
    }

    @Override
    public void atualizar(int id, Funcionario object) {
        for (Funcionario f: funcionarios)
            if (f.getId() == id)
                f = object;
    }

    @Override
    public void remover(Funcionario object) {
        funcionarios.remove(object);
    }

    @Override
    public void remover(int id) {
        funcionarios.removeIf(f -> f.getId() == id);
    }

    @Override
    public void delete(Funcionario object) {
        object.setDeleted(true);
    }

    @Override
    public void deleteById(int id) {
        //var query = "DELETE FROM COLECAO WHERE ID = ?";
        var query = "UPDATE FUNCIONARIOACESSI SET DELETED = 1 WHERE ID = ?";
        try(var conn =  DatabaseConfig.getConnection())
        {
            var stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            var result = stmt.executeUpdate();
            if(result > 0)
                logger.info("Funcionário removido com sucesso!");
        }
        catch (SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
    }

    @Override
    public List<Funcionario> listarTodos() {
        var funcionariosDb = new ArrayList<Funcionario>();
        var query = "SELECT * FROM FUNCIONARIOACESSI";
        try (var connection = DatabaseConfig.getConnection())
        {
            var statement = connection.prepareStatement(query);
            var result = statement.executeQuery();
            while (result.next())
            {
                var funcionario = new Funcionario();
                funcionario.setId(result.getInt("id"));
                funcionario.setDeleted(result.getBoolean("deleted"));
                funcionario.setNome(result.getString("nome"));
                funcionario.setEmail(result.getString("email"));
                funcionario.setSenha(result.getString("senha"));
                funcionario.setCargo(result.getString("cargo"));
                funcionariosDb.add(funcionario);
            }
            connection.close();
            return funcionariosDb;
        }
        catch (SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
        return null;
    }

    @Override
    public List<Funcionario> listar() {
        var funcionariosDb = new ArrayList<Funcionario>();
        var query = "SELECT * FROM USUARIOACESSI WHERE DELETED = 0";
        try (var connection = DatabaseConfig.getConnection())
        {
            var statement = connection.prepareStatement(query);
            var result = statement.executeQuery();
            while (result.next())
            {
                var funcionario = new Funcionario();
                funcionario.setId(result.getInt("id"));
                funcionario.setDeleted(result.getBoolean("deleted"));
                funcionario.setNome(result.getString("nome"));
                funcionario.setEmail(result.getString("email"));
                funcionario.setSenha(result.getString("senha"));
                funcionario.setCargo(result.getString("cargo"));
                funcionariosDb.add(funcionario);
            }
            return funcionariosDb;
        }
        catch (SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
        return null;
    }

    @Override
    public Optional<Funcionario> buscarPorId(int id) {
        var query = "SELECT * from COLECAO WHERE ID = ?";
        try(var connection = DatabaseConfig.getConnection()){
            var stmt = connection.prepareStatement(query);
            stmt.setInt(1, id);
            var result = stmt.executeQuery();
            if(result.next()){
                var funcionario = new Funcionario();
                funcionario.setId(result.getInt("id"));
                funcionario.setDeleted(result.getBoolean("deleted"));
                funcionario.setNome(result.getString("nome"));
                funcionario.setEmail(result.getString("email"));
                funcionario.setSenha(result.getString("senha"));
                funcionario.setCargo(result.getString("cargo"));

                return Optional.of(funcionario);
            }
        }
        catch(SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
        return Optional.empty();
    }
}
