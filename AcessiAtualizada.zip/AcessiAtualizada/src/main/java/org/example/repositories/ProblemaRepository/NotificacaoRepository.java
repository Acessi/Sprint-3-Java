package org.example.repositories.ProblemaRepository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.entities.Pessoa.Usuario;
import org.example.entities.Problema.Notificacao;
import org.example.infrastructure.DatabaseConfig;
import org.example.repositories.CrudRepository;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class NotificacaoRepository implements CrudRepository<Notificacao> {
    public static Logger logger = LogManager.getLogger(NotificacaoRepository.class);
    private List<Notificacao> notificacoes = new ArrayList<>(List.of());

    @Override
    public void adicionar(Notificacao object) {
        var query = "INSERT INTO NOTIFICACAOACESSI (DELETED, MENSAGEM, DATAHORA, TITULO) VALUES (?,?,?,?)";
        try(var conn = DatabaseConfig.getConnection())
        {
            var stmt = conn.prepareStatement(query);
            stmt.setBoolean(1, false);
            stmt.setString(2, object.getMensagem());
            stmt.setTimestamp(3, Timestamp.valueOf(object.getDataHora()));
            stmt.setString(4, object.getTitulo());
            var result = stmt.executeUpdate();
            if(result > 0)
                logger.info("Notificação adicionada com sucesso!");
        }
        catch(SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
    }

    @Override
    public void atualizar(int id, Notificacao object) {
        for (Notificacao n: notificacoes)
            if (n.getId() == id)
                n = object;
    }

    @Override
    public void remover(Notificacao object) {
        notificacoes.remove(object);
    }

    @Override
    public void remover(int id) {
        notificacoes.removeIf(n -> n.getId() == id);
    }

    @Override
    public void delete(Notificacao object) {
        object.setDeleted(true);
    }

    @Override
    public void deleteById(int id) {
        var query = "UPDATE NOTIFICACAOACESSI SET DELETED = 1 WHERE ID = ?";
        try(var conn =  DatabaseConfig.getConnection())
        {
            var stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            var result = stmt.executeUpdate();
            if(result > 0)
                logger.info("Notificação removida com sucesso!");
        }
        catch (SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
    }

    @Override
    public List<Notificacao> listarTodos() {
        var notificacoesDb = new ArrayList<Notificacao>();
        var query = "SELECT * FROM NOTIFICACAOACESSI";
        try (var connection = DatabaseConfig.getConnection())
        {
            var statement = connection.prepareStatement(query);
            var result = statement.executeQuery();
            while (result.next())
            {
                var notificacao = new Notificacao();
                notificacao.setId(result.getInt("id"));
                notificacao.setDeleted(result.getBoolean("deleted"));
                notificacao.setMensagem(result.getString("mensagem"));
                notificacao.setTitulo(result.getString("titulo"));
                notificacao.setDataHora(result.getTimestamp("dataHora").toLocalDateTime());
                notificacoesDb.add(notificacao);
            }
            connection.close();
            return notificacoesDb;
        }
        catch (SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
        return null;
    }

    @Override
    public List<Notificacao> listar() {
        var notificacoesDb = new ArrayList<Notificacao>();
        var query = "SELECT * FROM NOTIFICACAOACESSI WHERE DELETED = 0";
        try (var connection = DatabaseConfig.getConnection())
        {
            var statement = connection.prepareStatement(query);
            var result = statement.executeQuery();
            while (result.next())
            {
                var notificacao = new Notificacao();
                notificacao.setId(result.getInt("id"));
                notificacao.setDeleted(result.getBoolean("deleted"));
                notificacao.setMensagem(result.getString("mensagem"));
                notificacao.setTitulo(result.getString("titulo"));
                notificacao.setDataHora(result.getTimestamp("dataHora").toLocalDateTime());
                notificacoesDb.add(notificacao);
            }
            return notificacoesDb;
        }
        catch (SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
        return null;
    }

    @Override
    public Optional<Notificacao> buscarPorId(int id) {
        var query = "SELECT * from NOTIFICACAOACESSI WHERE ID = ?";
        try(var connection = DatabaseConfig.getConnection()){
            var stmt = connection.prepareStatement(query);
            stmt.setInt(1, id);
            var result = stmt.executeQuery();
            if(result.next()){
                var notificacao = new Notificacao();
                notificacao.setId(result.getInt("id"));
                notificacao.setDeleted(result.getBoolean("deleted"));
                notificacao.setMensagem(result.getString("mensagem"));
                notificacao.setTitulo(result.getString("titulo"));
                notificacao.setDataHora(result.getTimestamp("dataHora").toLocalDateTime());
                return Optional.of(notificacao);
            }
        }
        catch(SQLException e){
            e.printStackTrace();
            logger.error(e);
        }
        return Optional.empty();
    }
}
